<template>
  <div class="todo-container">
    <input
      v-model="newTodo"
      placeholder="Add a todo"
      @keydown.enter="addTodo"
      aria-label="Add todo"
      data-testid="todo-input"
    />
    <button @click="addTodo" data-testid="add-button">Add</button>

    <p v-if="error" class="error" role="alert">{{ error }}</p>

    <ul>
      <li v-for="todo in filteredTodos" :key="todo.id" data-testid="todo-item">
        {{ todo.text }}
        <button @click="deleteTodo(todo.id)" data-testid="delete-button">Delete</button>
      </li>
    </ul>

    <label for="filter">Filter:</label>
    <select v-model="filter" id="filter" data-testid="filter-select">
      <option value="all">All</option>
      <option value="short">Short (≤ 10 chars)</option>
      <option value="long">Long (> 10 chars)</option>
    </select>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'

const newTodo = ref('')
const todos = ref([])
const filter = ref('all')
const error = ref('')

function generateId() {
  return crypto.randomUUID ? crypto.randomUUID() : Date.now()
}

function addTodo() {
  error.value = ''

  const trimmed = newTodo.value.trim()
  if (!trimmed) {
    error.value = 'Todo cannot be empty'
    return
  }

  const duplicate = todos.value.some(todo => todo.text === trimmed)
  if (duplicate) {
    error.value = 'Todo already exists'
    return
  }

  todos.value.push({
    id: generateId(),
    text: trimmed
  })

  newTodo.value = ''
}

function deleteTodo(id) {
  todos.value = todos.value.filter(todo => todo.id !== id)
}

const filteredTodos = computed(() => {
  if (filter.value === 'short') return todos.value.filter(t => t.text.length <= 10)
  if (filter.value === 'long') return todos.value.filter(t => t.text.length > 10)
  return todos.value
})
</script>

<style scoped>
.todo-container {
  max-width: 400px;
  margin: auto;
  padding: 1rem;
}

.error {
  color: red;
  font-size: 0.9rem;
  margin: 0.5rem 0;
}

ul {
  list-style: none;
  padding-left: 0;
}

li {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0.25rem 0;
}

button {
  margin-left: 0.5rem;
}
</style>
