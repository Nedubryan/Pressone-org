// tests/setup.js
// This file is automatically run before each test suite by Vitest
// You can use it to set up global configurations, mocks, or polyfills

// Example: Add custom matchers with @testing-library/jest-dom
import '@testing-library/jest-dom'

// Example: Add a global variable for tests (if needed)
// globalThis.myCustomVariable = 'test-value'

// Example: Silence console warnings during tests
// jest.spyOn(console, 'warn').mockImplementation(() => {})

// You can add more setup here as needed
