import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import path from 'path'

export default defineConfig({
  plugins: [vue()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src')
    }
  },
  test: {
    globals: true,
    environment: 'jsdom',
    setupFiles: './tests/setup.js',
    // Exclude Playwright E2E tests from Vitest
    exclude: ['e2e/**', 'node_modules/**'],
    // Fix deprecation: use server.deps.inline instead of deps.inline
    server: {
      deps: {
        inline: ['@vue', 'vue']
      }
    }
  }
})
